/**
 * 
 */
package question25;

/**
 * @author Samyuktha Pandula
 *
 */
public interface DefaultMethodEx {
	 default void print() {
	      System.out.println("I am a four wheeler!");
	   }
}
