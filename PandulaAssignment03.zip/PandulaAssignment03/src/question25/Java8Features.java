/**
 * 
 */
package question25;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * @author Samyuktha Pandula
 *
 */
public class Java8Features {
	public static void main(String[] ar) {
		 ArrayList<Integer> numbers = new ArrayList<Integer>();
		    numbers.add(5);
		    numbers.add(9);
		    //lambda expression
		    numbers.forEach( (n) -> { System.out.println(n); } );
		    
		    List<String> names = Arrays.asList("Alice", "Bob", "Charlie", "David");

		 // sequential stream
		 names.stream()
		     .filter(name -> name.startsWith("A"))
		     .forEach(System.out::println);

		 // parallel stream
		 names.parallelStream()
		     .filter(name -> name.startsWith("D"))
		     .forEach(System.out::println);
	}

}
