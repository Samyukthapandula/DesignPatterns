/**
 * 
 */
package question8;

/**
 * @author Samyuktha Pandula
 *
 */
public class TryWithoutCatch {
	public static void main(String [] ar) {
	try {
		System.out.println("in try block");
	}
	finally {
		System.out.println("in finally");
	}
	}
}
