/**
 * 
 */
package question9;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

/**
 * @author Samyuktha Pandula
 *
 */
public class TryWithResource {
	public static void main(String [] ar) throws FileNotFoundException, IOException {
		try  {
			BufferedReader br = new BufferedReader(new FileReader("example.txt"));
			
		}
		catch (Exception e) {
            e.printStackTrace();
        }
	           
	}

}
