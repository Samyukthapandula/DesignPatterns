/**
 * 
 */
package question15;

import java.util.HashMap;
import java.util.Hashtable;

/**
 * @author Samyuktha Pandula
 *
 */
public class HashMapAndHashTable {
	public static void main(String [] ar) {
		 Hashtable<Integer,String> ht=new Hashtable<Integer,String>();
 
	        //----------------hashmap--------------------------------
	        HashMap<Integer,String> hm=new HashMap<Integer,String>();

	}
	
}
