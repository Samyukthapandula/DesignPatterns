/**
 * 
 */
package question3;

/**
 * @author Samyuktha Pandula
 *
 */
public class SuperClass {
	SuperClass get() {
    System.out.println("SuperClass");
    return this;
 }

}
