/**
 * 
 */
package question3;

/**
 * @author Samyuktha Pandula
 *
 */
public class SubClass extends SuperClass{

	SubClass get() {
	      System.out.println("SubClass");
	      return this;
	   }

}
