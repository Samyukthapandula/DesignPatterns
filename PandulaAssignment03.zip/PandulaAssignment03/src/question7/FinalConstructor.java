/**
 * 
 */
package question7;

/**
 * @author Samyuktha Pandula
 *
 */
public class FinalConstructor {

	
	/*
	 * public final FinalConstructor() { }
	 */
	
	

}
