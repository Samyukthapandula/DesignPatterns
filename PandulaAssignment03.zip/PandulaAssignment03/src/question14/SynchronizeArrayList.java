/**
 * 
 */
package question14;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * @author Samyuktha Pandula
 *
 */
public class SynchronizeArrayList {
	List<String> al =new ArrayList<>();
	List<String> synchronizedList = Collections.synchronizedList(al);
	
	CopyOnWriteArrayList<String> threadSafeList = new CopyOnWriteArrayList<String>();

}
