/**
 * 
 */
package question12;

/**
 * @author Samyuktha Pandula
 *
 */
public class FinalFinalizeFinally {
	public final double pi=3.14;
	public static void main(String[] ar) {
		try {
			
		}
	finally {
		
	}
	}
	@Override
	protected void finalize() throws Throwable {
		super.finalize();
	}
	
}
