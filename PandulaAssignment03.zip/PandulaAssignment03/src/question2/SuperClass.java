/**
 * 
 */
package question2;

/**
 * @author Samyuktha Pandula
 *
 */
public class SuperClass {
	public void publicMethod() {
        System.out.println("Public method");
    }
    
    protected void prtectedMethod() {
        System.out.println("Protected method");
    }
    
    void defaultMethod() {
        System.out.println("Default method");
    }
    
    private void privateMethod() {
        System.out.println("Private method");
    }

}
