/**
 * 
 */
package question2;

/**
 * @author Samyuktha Pandula
 *
 */
public class SubClass extends SuperClass{
	public void publicMethod() {
        System.out.println("public method");
    }
    
    protected void method2() {
        System.out.println("protected method");
    }
    
    void method3() {
        System.out.println("default method");
    }
    
    private void method4() {
        System.out.println("private method");
     }

}
