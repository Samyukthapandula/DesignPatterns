/**
 * 
 */
package question19;

/**
 * @author Samyuktha Pandula
 *
 */
public class creatingThread {
	public static void main(String[] args) {
		ExtendingThread t1 = new ExtendingThread();
		t1.start();
		
		ImplementingRunnable runnable = new ImplementingRunnable();
		Thread t2 = new Thread(runnable);
		t2.start();
	}

}

class ExtendingThread extends Thread {
	@Override
	public void run() {
		System.out.println("extending thread class");
	}
}

class ImplementingRunnable implements Runnable {
	@Override
	public void run() {
		System.out.println("implementing runable interface");
		}

}
