/**
 * 
 */
package question10;

import java.io.IOException;

/**
 * @author Samyuktha Pandula
 *
 */
public class SubClass extends SuperClass{
	/*
	 * public void readFile() throws Exception { }
	 */

}
