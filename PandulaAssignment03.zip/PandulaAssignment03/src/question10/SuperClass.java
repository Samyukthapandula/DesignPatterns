/**
 * 
 */
package question10;

import java.io.IOException;

/**
 * @author Samyuktha Pandula
 *
 */
public class SuperClass {
	
	public void readFile() throws IOException {
    }

}
