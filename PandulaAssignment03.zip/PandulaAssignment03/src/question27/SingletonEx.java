/**
 * 
 */
package question27;

/**
 * @author Samyuktha Pandula
 *
 */
public class SingletonEx {

	private static SingletonEx single_instance = null;
	public String s;
    private SingletonEx()
    {
        s = "hello";
    }
    public static SingletonEx Singleton()
    {
        if (single_instance == null) {
            single_instance = new SingletonEx();
        }
        return single_instance;
    }
}
