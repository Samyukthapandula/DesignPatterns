/**
 * 
 */
package question27;

/**
 * @author Samyuktha Pandula
 *
 */
public class SingletonMain {
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		SingletonEx x = SingletonEx.Singleton();
		SingletonEx y = SingletonEx.Singleton();
		System.out.println("String from x is " + x.s);
        System.out.println("String from y is " + y.s);
	}
}
