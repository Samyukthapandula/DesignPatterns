/**
 * 
 */
package question18;

/**
 * @author Samyuktha Pandula
 *
 */
public class ThreadStart extends Thread{
	 public void run(){  
		   System.out.println("thread started");  
		 }  
		 public static void main(String args[]){  
			 ThreadStart t1=new ThreadStart();  
		  t1.start();  
		  t1.start();  
		 }  

}
