/**
 * 
 */
package question4;

/**
 * @author Samyuktha Pandula
 *
 */
public class SuperClass {
	private void privateMethod() {
        System.out.println("This is private Method ");
    }

    public static void StaticMethod() {
        System.out.println("This is Static Method");
    }

}
