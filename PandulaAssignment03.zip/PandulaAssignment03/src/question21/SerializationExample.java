/**
 * 
 */
package question21;

import java.io.FileOutputStream;
import java.io.ObjectOutputStream;

/**
 * @author Samyuktha Pandula
 *
 */
public class SerializationExample {
	public static void main(String[] ar) {
		try{    
			  Student s1 =new Student("sam",121);    
			  FileOutputStream fout=new FileOutputStream("output.txt");    
			  ObjectOutputStream out=new ObjectOutputStream(fout);    
			  out.writeObject(s1);    
			  out.flush();    
			  out.close();    
			  }catch(Exception e){System.out.println(e);}    
			 }    
	

}
class Student{
	String name;
	int id;

	public  Student(String name,int id) {
		this.name =name;
		this.id = id;
	}
}