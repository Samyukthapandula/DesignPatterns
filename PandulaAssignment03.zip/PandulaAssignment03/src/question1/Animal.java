/**
 * 
 */
package question1;

/**
 * @author Samyuktha Pandula
 *
 */
public class Animal<T> {
    private T value;

    public Animal(T value) {
        this.value = value;
    }

    public T getValue() {
        return value;
    }

    public void setValue(T value) {
        this.value = value;
    }
}

