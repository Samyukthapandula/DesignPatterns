/**
 * 
 */
package question17;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * @author Samyuktha Pandula
 *
 */
public class FailFastAndFailSafe {
	public static void main(String [] ar) {
		ArrayList<String> al = new ArrayList<>();
		
		Iterator<String> itr1 = al.iterator();
		// Fail-fast iterator
		while (itr1.hasNext()) {
			al.remove(itr1.next()); 
		}

		// Fail-safe iterator.
		Iterator<String> itr2 = al.iterator();
		List<String> copy = new ArrayList<>(al);
		itr2 = copy.iterator();
		while (itr2.hasNext()) {

			al.remove(itr2.next()); 
		}
	}

}
